package bjtu.edu.weibo.controller;

public class ProfileController {

}
