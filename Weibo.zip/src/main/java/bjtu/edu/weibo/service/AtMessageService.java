package bjtu.edu.weibo.service;

import bjtu.edu.weibo.model.User;

public interface AtMessageService {
	public boolean AtMessage(User user,User user1,String str);
}
