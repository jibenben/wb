package bjtu.edu.weibo.service;

import bjtu.edu.weibo.model.User;

public interface AttentionNumberService {
	public int getAttentionNumber(User user);
}
