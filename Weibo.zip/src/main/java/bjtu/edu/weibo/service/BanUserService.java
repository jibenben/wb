package bjtu.edu.weibo.service;

import bjtu.edu.weibo.model.User;

public interface BanUserService {
	public boolean BanUser(User user,User user1);
}
