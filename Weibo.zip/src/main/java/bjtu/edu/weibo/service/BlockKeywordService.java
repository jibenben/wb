package bjtu.edu.weibo.service;

public interface BlockKeywordService {
	public boolean AddBlockKeyword(String word);
	public boolean SubBlockKeyword(String word);
}
