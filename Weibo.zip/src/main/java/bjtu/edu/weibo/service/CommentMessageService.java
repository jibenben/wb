package bjtu.edu.weibo.service;

import bjtu.edu.weibo.model.Comment;

public interface CommentMessageService {
	public boolean CommentMessage(Comment comment,Comment comment1);
}
