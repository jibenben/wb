package bjtu.edu.weibo.service;

import bjtu.edu.weibo.model.User;

public interface FansNumberService {
	public int getFansmNuber(User user);
}
