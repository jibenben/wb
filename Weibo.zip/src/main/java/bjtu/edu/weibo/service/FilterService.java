package bjtu.edu.weibo.service;

public interface FilterService {
	public String Filter(String content);
}
