package bjtu.edu.weibo.service;

import java.util.List;

import bjtu.edu.weibo.model.Topic;

public interface HotTopicService {
	public List<Topic> HotTopic();
}
