package bjtu.edu.weibo.service;

import bjtu.edu.weibo.model.Picture;
import bjtu.edu.weibo.model.User;

public interface LikePictureService {
	public boolean LikePicture(User user ,Picture picture);

}
