package bjtu.edu.weibo.service;

public interface LoginService {
	public boolean loginService(String usename, String password);
}
