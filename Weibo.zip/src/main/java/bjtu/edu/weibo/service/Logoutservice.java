package bjtu.edu.weibo.service;

public interface Logoutservice {
	public boolean logout();
}
