package bjtu.edu.weibo.service;

public interface PicService {
	public boolean uploadpic();
}
