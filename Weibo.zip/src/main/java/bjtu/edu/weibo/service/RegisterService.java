package bjtu.edu.weibo.service;

public interface RegisterService {
	public Boolean registerNewUser(String username, String password);
}
