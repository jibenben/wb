package bjtu.edu.weibo.service;

import bjtu.edu.weibo.model.User;


public interface ReportUserService {
	public boolean ReportUser(User user,User user1);
}
