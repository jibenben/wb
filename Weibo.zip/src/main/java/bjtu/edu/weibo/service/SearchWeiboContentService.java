package bjtu.edu.weibo.service;

public interface SearchWeiboContentService {

}
