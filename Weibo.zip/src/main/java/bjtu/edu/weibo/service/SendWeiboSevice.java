package bjtu.edu.weibo.service;

public interface SendWeiboSevice {
	public boolean  AvilialbeGroup();
}
